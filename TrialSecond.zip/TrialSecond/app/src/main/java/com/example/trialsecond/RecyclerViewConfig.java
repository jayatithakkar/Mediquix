package com.example.trialsecond;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class RecyclerViewConfig {
    private Context con;

    private AdaptedData radap;

    public void setConfig(RecyclerView rv, Context cont, List<ActualData> ad, List<String> kwys){
        con=cont;
        radap=new AdaptedData(ad, kwys);
        rv.setLayoutManager(new LinearLayoutManager(cont));
        rv.setAdapter(radap);
    }
    class view extends RecyclerView.ViewHolder {
        private TextView rsub;
        private TextView rrat;
        private TextView ralgo;

        private String key;

        public view(ViewGroup parent){
            super(LayoutInflater.from(con).inflate(R.layout.recycler_layout, parent, false));
            rsub=(TextView) itemView.findViewById(R.id.rsubj);
            rrat=(TextView) itemView.findViewById(R.id.rrate);
            ralgo=(TextView) itemView.findViewById(R.id.rtime);


        }
        public void bind(ActualData ad, String key){
            rsub.setText(ad.Subject);
            rrat.setText(ad.Rating);
            ralgo.setText(ad.Algo);
            this.key=key;
        }
    }
    class AdaptedData extends RecyclerView.Adapter<view>{
        private List<ActualData> lst;
        private List<String> rkeys;

        public AdaptedData(List<ActualData> lst, List<String> rkeys) {
            this.lst = lst;
            this.rkeys = rkeys;
        }

        @NonNull
        @Override
        public view onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new view(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull view holder, int position) {
            holder.bind(lst.get(position), rkeys.get(position));
        }

        @Override
        public int getItemCount() {
            return lst.size();
        }
    }
}
