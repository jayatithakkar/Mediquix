package com.example.trialsecond;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FinalData extends AppCompatActivity {
    private Button next;
    private Button add;
    private EditText subj;
    private EditText rat;
    private TextView tv;
    private DatabaseReference mDatabase;
    String strsub, strrat, tsub;
    int cnt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_data);

        cnt=0;
        Intent i=getIntent();
        tsub=i.getStringExtra("hi");

        mDatabase = FirebaseDatabase.getInstance().getReference();
        subj=findViewById(R.id.sub_name);
        rat=findViewById(R.id.ratings);



        tv=findViewById(R.id.tv);
        final int hello=Integer.parseInt(tsub);
        add= (Button) findViewById(R.id.add_database);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strsub=subj.getText().toString();
                strrat=rat.getText().toString();
                cnt=cnt+1;
                if(cnt==hello){
                    add.setVisibility(view.INVISIBLE);
                    next.setVisibility(view.VISIBLE);
                }

                writeNewUser(tsub, strrat,cnt, strsub,"");

            }
        });

        next= (Button) findViewById(R.id.final_show);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent1);
            }
        });
    }

    private void writeNewUser(String tsub, String strrat, int i, String strsub,String algo) {
        ActualData ad= new ActualData(strrat,strsub,algo);


        mDatabase.child("TotalSubj").child(tsub).child(String.valueOf(i)).setValue(ad);
    }
}