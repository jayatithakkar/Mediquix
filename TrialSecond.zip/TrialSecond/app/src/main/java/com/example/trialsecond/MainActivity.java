package com.example.trialsecond;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListOptions;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    RecyclerView.LayoutManager lm;

    FirebaseDatabase db = FirebaseDatabase.getInstance();
    DatabaseReference ref=db.getReference("TotalSubj");
    private Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        rv= (RecyclerView) findViewById(R.id.rev);






        new FirebaseDatabaseHelper().readData(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<ActualData> ad, List<String> keys) {
                new RecyclerViewConfig().setConfig(rv, MainActivity.this, ad, keys);
            }
        });






        ref.child("1").child("1").child("Algo").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String i=snapshot.getValue().toString();
                /*int j=0;
                if(i!=null){
                    j=Integer.parseInt(i);
                }*/
                Toast.makeText(MainActivity.this,String.valueOf(i),Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btn1= (Button) findViewById(R.id.new_schedule);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(getApplicationContext(),TotalData.class);
                startActivity(intent1);

            }
        });
    }

}